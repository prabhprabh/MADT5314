//
//  InterfaceController.swift
//  hello WatchKit Extension
//
//  Created by MacStudent on 2019-03-01.
//  Copyright © 2019 MacStudent. All rights reserved.
//

import WatchKit
import Foundation
import MapKit


class InterfaceController: WKInterfaceController {

    @IBOutlet weak var mapObject: WKInterfaceMap!
    @IBOutlet weak var timer: WKInterfaceTimer!
    let lat = 43.6532
    let long = 79.3832
    var mapLocation:CLLocationCoordinate2D?
    
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        // Configure interface objects here.
    }
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
        /*
        mapLocation = CLLocationCoordinate2D(latitude: lat,longitude: long)
        let span = MKCoordinateSpan(latitudeDelta: 0.1,longitudeDelta: 0.1)
        let region = MKCoordinateRegion(center: mapLocation!, span: span)
        mapObject.setRegion(region)
 */
       
        

    }
    
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }
    
    @IBAction func startBtn() {
        
        timer.start()
    }
    
    
    @IBAction func stopBtn() {
        timer.stop()
        
    }
    

}
